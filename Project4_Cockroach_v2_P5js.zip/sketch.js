                    
/* 
 *  C20 - p5.js WebSocket LED
 *  Creating a fancy interactive user interface 
 *  capable of communicating via WebSocket in p5.js
 *  
 *  
 */

// where the cockroach SocketServer is (your local machine):
var host = 'XXXXXXXX.lhr.life';  // Change this to your CockroachBot IP Address 
var socket; // the websocket
var ledValue = 0; // the sensor value
var ultraSonicValue = 0; // Ultrasonic Value

function setup() {
  createCanvas(400, 400);
  
  
  button = createButton('Toggle');
  button.position(160, 50);
  button.mousePressed(ToggleLED);
  
  forward = createButton('▲');
  forward.position(170, 100);
  forward.mousePressed(SendMovement);
  
  backward = createButton('▼');
  backward.position(170, 160);
  backward.mousePressed(SendMovement);
  
  left = createButton('◄');
  left.position(130, 130);
  left.mousePressed(SendMovement);
  
  right = createButton('►');
  right.position(210, 130);
  right.mousePressed(SendMovement);
  
  stop = createButton('■');
  stop.position(173, 130);
  stop.mousePressed(SendMovement);
  
  // connect to server:
  socket = new WebSocket('wss://' + host);
  socket.onopen = sendIntro;
  // socket message listener:
  socket.onmessage = readMessage;
}

function draw() {
  if (ledValue == 1) {
    background("#2307AF");
  }
  else {
    background("#FFA500");
  }
  text("CockroachBot WebSocket Server", 10, 20);
  fill(255);
  ellipse(150, 60, (ledValue * 10) + 5);
  text("Distance = " + ultraSonicValue + "mm", 250, 20);
  
}

function ToggleLED() {
  socket.send("toggle");
}

function SendMovement(movement) {
  // console.log(movement.srcElement.innerText.includes("▲"));
  socket.send(movement.srcElement.innerText.includes("▲")? "Forward":
              movement.srcElement.innerText.includes("▼")? "Backward":
              movement.srcElement.innerText.includes("◄")? "Left":
              movement.srcElement.innerText.includes("►")? "Right":
              movement.srcElement.innerText.includes("■")? "Stop":"toggle");
}

function sendIntro() {
  // convert the message object to a string and send it:
  socket.send("toggle");
}

function readMessage(event) {
  var msg = event.data; // read data from the onmessage event
  
  if (event.data == "LED=1"){
    ledValue = 1; 
  }
  else if (event.data == "LED=0"){
    ledValue = 0; 
  }
  else if (event.data.includes("Ultrasonic=")) {
    ultraSonicValue = event.data.substring(11);
  }
}
                    
                